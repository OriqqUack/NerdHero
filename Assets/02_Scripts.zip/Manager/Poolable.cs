using UnityEngine;

public class Poolable : MonoBehaviour
{
    public bool IsUsing;
}
