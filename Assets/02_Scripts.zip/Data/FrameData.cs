using UnityEngine;

[System.Serializable]
public class FrameData
{
    public Sprite Sprite;
    public string Description;
}
