using UnityEngine;

public abstract class UI_Popup : MonoBehaviour
{
    
    public abstract void Close();
}
