using UnityEngine;

public class UI_RewardBox : UiWindow
{
    
}
