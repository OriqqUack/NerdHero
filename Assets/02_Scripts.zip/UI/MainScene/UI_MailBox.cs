using UnityEngine;

public class UI_MailBox : UiWindow
{
    
}
