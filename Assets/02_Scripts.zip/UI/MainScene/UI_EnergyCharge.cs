using UnityEngine;

public class UI_EnergyCharge : UiWindow
{
    
}
