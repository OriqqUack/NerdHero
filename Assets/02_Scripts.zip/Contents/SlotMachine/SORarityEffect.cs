using UnityEngine;

[CreateAssetMenu(fileName = "SORarirty_", menuName = "SlotMachine/RarityEffects")]
public class SORarityEffect : ScriptableObject
{
    public Effect[] effects;
}
