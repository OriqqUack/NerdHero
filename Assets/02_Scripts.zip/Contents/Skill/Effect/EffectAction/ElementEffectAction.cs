using UnityEngine;

[System.Serializable]
public abstract class ElementEffectAction : EffectAction
{
    public GameObject vfxEffectPrefab;
}
