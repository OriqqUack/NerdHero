using UnityEngine;

[System.Serializable]
public abstract class CardCondition : Condition<Skill>
{
}
