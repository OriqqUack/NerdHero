public enum SkillExecuteCommand { Use, UseImmediately, Cancel, CancelImmediately }
public enum SkillStateMessage { Use }
