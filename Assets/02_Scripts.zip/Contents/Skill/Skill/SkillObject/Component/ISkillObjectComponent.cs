using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISkillObjectComponent
{
    public void OnSetupSkillObject(SkillObject skillObject);
    public void OnSetupSkillObject(SkillColliderObject skillObject);
}
